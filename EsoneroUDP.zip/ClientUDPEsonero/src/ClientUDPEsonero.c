#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <float.h>
#include <math.h>
#include "utils.h"



int checkString(char operation[]){
	int i = 3;
	int j = 1;

	if(operation[0] == '='){
		while(operation[j] == ' '){ //we allow the user to close the connection using a string which is composed by '=' followed by blankspaces or followed by nothing
			j++;
		}
		if(((int)operation[j]) == 10){
			return 1;
		}
		else{
			return 0;
		}
	}

	else if(((operation[0] == '+') || (operation[0] == '-') || (operation[0] == '*') || (operation[0] == '/'))//checking if the first position is a symbol,
			&& (isspace(operation[1])) && (isdigit(operation[2]))){ 										 //then if we have a blankspace and a number
		while((isdigit(operation[i]))){
			i++;

		}
		if((isspace(operation[i])) && (isdigit(operation[i+1]))){ //only one space allowed between symbol and first value and between the values
			i = i+2;
			while((isdigit(operation[i]))){// in this case, we do not allow blankspaces after the second value because it doesn't fit the operation structure
						i++;
					}
			if(((int)operation[i]) == 10){ //transforming the last character into his ASCII code to make possible to check if it is '\n'
				return 1;
			}
			else{
				return 0;
			}
		}
		else{
			return 0;
		}
	}
	else{
		return 0;
	}
}


int main(int argc, char *argv[]){

	int sock;
	int port;
	struct sockaddr_in echoServerAddr;
	struct sockaddr_in fromAddr;
	unsigned int fromSize;
	char operation[MAXDIM];
	char operationBuffer[MAXDIM];
	int echoStringLen;
	int respStringLen;
	char serverName[MAXDIM];
	char hostName[MAXDIM];
	char portNumber[MAXDIM];
	struct hostent* host;
	struct values values;


#if defined WIN32
	printf("Initialising Winsock...\n");
	WSADATA wsaData;
	if (WSAStartup(MAKEWORD(2,2), &wsaData) != 0){
		printf("Error at WSAStartup\n");
		return EXIT_FAILURE;
	}
	printf("WinSock initialised.\n");
#endif




   	if (argc > 1) {
   		strcpy(serverName, argv[1]);
   		stringManipulation(serverName, hostName, portNumber); //tokenizing hostName and portNumber
   		port = atoi(portNumber);
   		host = gethostbyname(hostName);
    }
   	else{
   		port = (int)PORT;
   		host = gethostbyname("localhost");
   	}


	if (host == NULL){
		printf("Connection failed.\n");
		exit(EXIT_FAILURE);
	}

	if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) == SOCKET_ERROR){
		printf("Could not create socket");
		exit(EXIT_FAILURE);
	}

	memset(&echoServerAddr, 0, sizeof(echoServerAddr));
	echoServerAddr.sin_family = PF_INET;
	echoServerAddr.sin_port = htons(port);
	memcpy((char *) &echoServerAddr.sin_addr.s_addr, host->h_addr_list[0], host->h_length);

	while(1){
		printf("Operation format: symbol value value (Ex. + 3 2)\n"); //even if we're using floats, user has to use integer values for the operations
		printf("Insert an operation: ");
		fgets(operation, sizeof(operation), stdin);
		if(checkString(operation) == 1){
			if(operation[0] == '='){
				closesocket(sock);
				ClearWinSock();
				return 0;
			}
			else{
				echoStringLen = strlen(operation);
				if (echoStringLen > MAXDIM){
					printf("Echo string too long.");
					break;
				}

				if (sendto(sock, operation, echoStringLen, 0, (struct sockaddr*)&echoServerAddr, sizeof(echoServerAddr))<0){
					printf("sendto() failed");
					exit(EXIT_FAILURE);
				}

				fromSize = sizeof(fromAddr);
				respStringLen = recvfrom(sock, operationBuffer, MAXDIM, 0, (struct sockaddr*)&fromAddr, &fromSize);

				if (echoServerAddr.sin_addr.s_addr != fromAddr.sin_addr.s_addr){
					printf("Error: received a packet from unknown source. \n");
					exit(EXIT_FAILURE);
				}

				operationBuffer[respStringLen] = '\0';
				printf("\nResult: %s\n", operationBuffer);
				printf("Received from: %s\n", host->h_name);
				printf("Address: %s\n\n", inet_ntoa(echoServerAddr.sin_addr));
			}

		}
		else{
			printf("Incorrect operation form\n\n");
		}
	}


	closesocket(sock);
	ClearWinSock();
	return 0;
}
