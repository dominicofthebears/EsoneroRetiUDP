#ifndef UTILS_H_
#define UTILS_H_

#define MAXDIM 512
#define NO_ERROR 0
#define PORT 48000

void stringManipulation(char str_1[], char str_2[], char str_3[]){
	int i = 0;
	int j = 0;
	while(str_1[i] != ':'){
		str_2[i] = str_1[i];
		i++;
	}
	str_2[i] = '\0';
	i++;

	while((int)str_1[i] != 10){
		str_3[j] = str_1[i];
		i++;
		j++;
	}
	str_3[j] = '\0';
}

void ClearWinSock() {
#if defined WIN32
	WSACleanup();
#endif
}


struct values {
	char symbol;
	char val1[MAXDIM];
	char val2[MAXDIM];
};

#endif /* UTILS_H_ */
