#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <float.h>
#include <math.h>
#include "utils.h"

#define ADDRESS "127.0.0.1"

float add(float val1, float val2){
	return val1+val2;
}

float mult(float val1, float val2){
	return val1*val2;
}

float sub(float val1, float val2){
	return val1-val2;
}

float division(float val1, float val2){ //using floats to avoid problems with divisions like 4/5
	if(val2!=0){
		return val1/val2;
	}
	else{
		return FLT_MAX; //returning FLOAT_MAX as an error value to the client if dividing by zero, as a sort of "infinite" value
	}
}

float makeOperation(struct values values){
	float val1 = atoi(values.val1);
	float val2 = atoi(values.val2);
	float result = 0;
	switch(values.symbol){

		case '+':
			result = add(val1, val2);
			break;

		case '-':
			result = sub(val1, val2);
			break;

		case '*':
			result = mult(val1, val2);
			break;

		case '/':
			result = division(val1, val2);
			break;
	}
	return result;
}


void buildResult(char resultString[], struct values values, float result){
	int i=0;
	int j=0;
	int k=0;
	float integerRes = 0;
	char res[MAXDIM];
	if(modff(result, &integerRes)>0){
		gcvt(result, 8, res);
	}
	else{
		itoa((int)integerRes, res, 10); //deleting values after the . if they're all 0s
	}
	if(result == FLT_MAX){
		strcpy(resultString, "Impossible operation, dividing by zero");
	}
	else{
		while(values.val1[i]!='\0'){
			resultString[i] = values.val1[i];
			i++;
		}
		resultString[i] = ' ';
		resultString[i+1] = values.symbol;
		resultString[i+2] = ' ';
		i = i+3;

		while(values.val2[j]!='\0'){
			if((int)values.val2[j] == 10){
				j++;
			}
			else{
				resultString[i] = values.val2[j];
				j++;
				i++;
			}

		}

		resultString[i] = ' ';
		resultString[i+1] = '=';
		resultString[i+2] = ' ';
		i = i+3;

		while(res[k]!='\0'){
			resultString[i] = res[k];
			k++;
			i++;
		}
		resultString[i] = '\0';
	}

}

struct values tokenizeValues(char operation[]){
	struct values val;
	int i=2;
	int j=0;
	int k=0;
	val.symbol = operation[0];

	if(val.symbol == '='){
		return val;
	}
	else{
		while(operation[i]!=' '){
			val.val1[j]=operation[i];
			i++;
			j++;
		}
		val.val1[j] = '\0';
		i++;

		while(operation[i]!='\0'){
			val.val2[k]=operation[i];
			i++;
			k++;
		}
		val.val2[k] = '\0';
		return val;
	}
}


int main(int argc, char *argv[]){

#if defined WIN32
	printf("Initialising WinSock...\n");
	WSADATA wsaData;
	if (WSAStartup(MAKEWORD(2,2), &wsaData) != 0){
		printf("Failed to initialize winsock\n");
		return EXIT_FAILURE;
	}
	printf("WinSock initialised.\n");
#endif

	int sock;
	struct sockaddr_in echoServerAddr;
	struct sockaddr_in echoClntAddr;
	unsigned int cliAddrLen;
	struct values values;
	int recvMsgSize;
	struct hostent* host;
	float result = 0;
	char resultString[MAXDIM];
	char operation[MAXDIM];
	char serverName[MAXDIM];
	char ipAddr[MAXDIM];
	char portNumber[MAXDIM];



	if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) == SOCKET_ERROR){
		printf("Could not create socket");
	}
	printf("Socket created.\n");


	memset(&echoServerAddr, 0, sizeof(echoServerAddr));
	echoServerAddr.sin_family = AF_INET;

   	if (argc > 1) {
   		strcpy(serverName, argv[1]);
   		stringManipulation(serverName, ipAddr, portNumber);
   		echoServerAddr.sin_addr.s_addr = inet_addr(ipAddr);
   		echoServerAddr.sin_port = htons(atoi(portNumber));

    }
   	else{
   		echoServerAddr.sin_port = htons(PORT);
   		echoServerAddr.sin_addr.s_addr = inet_addr(ADDRESS);
   	}



	if ((bind(sock, (struct sockaddr *)&echoServerAddr, sizeof(echoServerAddr))) == SOCKET_ERROR){
		printf("Bind failed\n");
		exit(EXIT_FAILURE);
	}

	while(1){
		printf("Waiting for an operation...\n\n");

		memset(operation, '\0', MAXDIM);
		cliAddrLen = sizeof(echoClntAddr);
		recvfrom(sock, operation, MAXDIM, 0, (struct sockaddr*)&echoClntAddr, &cliAddrLen); //receiving the operation
		host = gethostbyaddr((char*) &(echoClntAddr.sin_addr), 4, AF_INET);

		printf("Operation request: %s", operation);
		printf("Request received from: %s\n", host->h_name ); //printing client name
		printf("Address: %s\n\n", inet_ntoa(echoClntAddr.sin_addr)); //printing client address
		values = tokenizeValues(operation);
		if(atoi(values.val1)<10000 && atoi(values.val2)<10000){ //we impose a limit on the values as suggested, avoiding results greater than MAX_FLOAT
			result = makeOperation(values);
			buildResult(resultString, values, result); //building the result string to send back
		}
		else{
			strcpy(resultString, "Values are too big");
		}
			if(sendto(sock, resultString, strlen(resultString), 0, (struct sockaddr *)&echoClntAddr, sizeof(echoClntAddr)) != strlen(resultString)){
				printf("sendto() failed");
				exit(EXIT_FAILURE);
			}
	}
	closesocket(sock);
	ClearWinSock();
	return 0;

}
